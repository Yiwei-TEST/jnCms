<?php

namespace app\home\model;
use think\Model;
use think\Db;

class BaseModel extends Model
{




}
