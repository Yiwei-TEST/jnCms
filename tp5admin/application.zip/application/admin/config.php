<?php

return [
    //模板参数替换
    'view_replace_str' => array(
        '__CSS__' => '/static/admin/css',
        '__JS__'  => '/static/admin/js',
        '__IMG__' => '/static/admin/images',		
    ),
    "api_prefix" =>"/pdklogin/",
    "api_url" =>"http://192.168.1.112:8081",//接口地址
    "api_key" => "dKPVJ60PJS8mlONb",
    "api_vi" => "dKPVJ60PJS8mlONb",
    "is_decrypt" => "0",  //1 需要解密
];
